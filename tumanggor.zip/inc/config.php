<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "tumanggor";


$konek = mysqli_connect($host, $user, $pass, $dbname);
